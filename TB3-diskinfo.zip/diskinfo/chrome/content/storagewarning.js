function DEBUG(msg) {
  dump("MSG: " + msg + "\n");
}

var storagewarning = {
  on_load: function() {
    document.documentElement.getButton("accept").focus();
    this.show = 1;
  },
  on_cancel: function() {
    dump("cancel\n");
    this.show = 0;
  },
  on_ok: function() {
    dump("ok\n");
    this.show = 0;
  }
};
