function DEBUG(msg) {
  dump("MSG: " + msg + "\n");
}

const prefB = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);
const notifyTimeout=20000;

var myPrefObserver = {
  register: function() {
    var prefService = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
    this._branch = prefService.getBranch("mail.view_font_size");
    this._branch.QueryInterface(Components.interfaces.nsIPrefBranch2);
    this._branch.addObserver("", this, false);
  },
  unregister: function() {
    if(!this._branch) return;
    this._branch.removeObserver("", this);
  },
  observe: function(aSubject, aTopic, aData) {
    if(aTopic == "nsPref:changed") {
      diskinfo.applyMailViewFontSize();
    }
  }
}

var myPop3PrefObserver = {
  register: function() {
    var prefService = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
    this._branch = prefService.getBranch("mail.server");
    this._branch.QueryInterface(Components.interfaces.nsIPrefBranch2);
    this._branch.addObserver("", this, false);
  },
  unregister: function() {
    if(!this._branch) return;
    this._branch.removeObserver("", this);
  },
  observe: function(aSubject, aTopic, aData) {
    if(aTopic == "nsPref:changed") {
      key = "mail.server" + aData;
      if(key.indexOf("num_mail_get_from_server") > 0) {
        var val = prefB.getIntPref(key);
        var newkey = key.replace("num_mail_get_from_server", "numHdrsToKeep");
        prefB.setIntPref(newkey, val);
      } else if(key.indexOf("numHdrsToKeep") > 0) {
        var newkey = key.replace("numHdrsToKeep","num_mail_get_from_server");
        try {
          var val = prefB.getIntPref(newkey);
        } catch(ex) {
          val = 200;
        }
        prefB.setIntPref(key, val);
      }
    }
  }
}

var myAppObserver = {
  register: function() {
    if(diskinfo.window_min_enable && diskinfo.window_min_enable == "false") {
      DEBUG("disable quit application observer");
    } else {
      var os = Components.classes["@mozilla.org/observer-service;1"].getService(Components.interfaces.nsIObserverService);
      os.addObserver(this, "quit-application-requested", false);
    }
  },
  unregister: function() {
    if(diskinfo.window_min_enable && diskinfo.window_min_enable == "false") {
    } else {
      var os = Components.classes["@mozilla.org/observer-service;1"].getService(Components.interfaces.nsIObserverService);
      os.removeObserver(this, "quit-application-requested");
    }
  },
  observe: function(aSubject, aTopic, aData) {
    DEBUG("aTopic " + aTopic);
    if(aTopic == "quit-application-requested") {
      aSubject.QueryInterface(Components.interfaces.nsISupportsPRBool);
      aSubject.data = true;
      var obj = Components.classes["@mozilla.org/jsutils;1"].getService(Components.interfaces.nsIJSUtils);
      var win = diskinfo.get_basewindow(window);
      obj.doWindowAction(win,  "MIN");
    }
  }
}

var dbListener = {
  onHdrAdded: function(aHdrChanged, aParentKey, aFlags, aInstigator) {
    try {
      var server = aHdrChanged.folder.server;
      var acct = diskinfo.acctMgr.FindAccountForServer(server);
      var msg_re_flag = 0;
      const RE_POSTABLE = 0x00000010;
      diskinfo.conn.clearMessage();
	  var notify_msg = acct.key;
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = "1";
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = aHdrChanged.messageId;
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = aHdrChanged.mime2DecodedSubject;
	  msg_re_flags = Number(aHdrChanged.flags - 65536);
	  msg_re_flags &= RE_POSTABLE;
	  DEBUG("flags : " + msg_re_flags);
	  if(msg_re_flags)
	      notify_msg = "Re: " + notify_msg;
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = aHdrChanged.mime2DecodedAuthor;
      diskinfo.conn.addMessage(notify_msg);
	  if(aHdrChanged.isRead)
		  notify_msg = "Read";
	  else
		  notify_msg = "Unread";
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = aHdrChanged.date;
      diskinfo.conn.addMessage(notify_msg);
	  diskinfo.conn.sendMessageNew(4);
      //diskinfo.conn.sendMessage(notify_msg);
      diskinfo.update_space_info();
    } catch(ex) {
      DEBUG("onHdrAdded: " + ex);
    }
  },
  onHdrDeleted: function(aHdrChanged, aParentKey, aFlags, aInstigator) {
    try {
      var acct = diskinfo.acctMgr.FindAccountForServer(aHdrChanged.folder.server);
      diskinfo.conn.clearMessage();
      var notify_msg = acct.key;
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = aHdrChanged.messageId;
      diskinfo.conn.addMessage(notify_msg);
	  diskinfo.conn.sendMessageNew(5);
      //diskinfo.conn.sendMessage(notify_msg);
      diskinfo.update_space_info();
    } catch(ex) {
      DEBUG("onHdrDeleted: " + ex);
    }
  },
  onHdrFlagsChanged: function(aHdrChanged, aOldFlags, aNewFlags, aInstigator) {
    try {
    var acct = diskinfo.acctMgr.FindAccountForServer(aHdrChanged.folder.server);
    DEBUG(acct.key + ": onHdrFlagsChanged " + aHdrChanged.mime2DecodedSubject + "messageId " + aHdrChanged.messageId);
    DEBUG("OldFlags " + aOldFlags + " NewFlags " + aNewFlags + " " + nsMsgMessageFlags.Expunged);
    if((aOldFlags & nsMsgMessageFlags.Read)==0) {
      if(aNewFlags & nsMsgMessageFlags.Read) {
        diskinfo.conn.clearMessage();
        var notify_msg = acct.key;
        diskinfo.conn.addMessage(notify_msg);
		notify_msg = "1";
        diskinfo.conn.addMessage(notify_msg);
		notify_msg = aHdrChanged.messageId;
        diskinfo.conn.addMessage(notify_msg);
        diskinfo.conn.sendMessageNew(6);
        //diskinfo.conn.sendMessage(notify_msg);
      }
    }
    } catch(ex) {
      DEBUG("onHdrFlagsChanged: " + ex);
    }
  }
}

var acctListener = {
  onServerLoaded: function(server) {
    try {
      if(server.type == "pop3" || server.type=="imap") {
        key = "mail.server." + server.key + ".mail_count_get_from_server";
        try {
          var val = prefB.getIntPref("mail.server.default.mail_count_get_from_server");
        } catch(ex) {
          val = 200;
        }
        prefB.setIntPref(key, val);

        try {
          val = prefB.getIntPref("mail.server.default.max_size");
        } catch(ex) {
          val = 500;
        }
        key = "mail.server." + server.key + ".max_size";
        prefB.setIntPref(key, val);

        prefB.setBoolPref("mail.server."+server.key+".limit_offline_message_size", true);
      }

      var acct = diskinfo.acctMgr.FindAccountForServer(server);
      diskinfo.conn.clearMessage();
      var notify_msg = acct.key;
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = acct.incomingServer.prettyName;
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = acct.incomingServer.type ;
      diskinfo.conn.addMessage(notify_msg);
	  notify_msg = acct.incomingServer.username +'@'+acct.incomingServer.hostName;
      diskinfo.conn.addMessage(notify_msg);
      diskinfo.conn.sendMessageNew(7);
      //diskinfo.conn.sendMessage(notify_msg);
      diskinfo.tray.addKeyValue(server.key, acct.key);

      var msgFolder = server.rootMsgFolder;
      var myFolder = msgFolder.getChildNamed(diskinfo.strInbox);
      Components.classes["@mozilla.org/msgDatabase/msgDBService;1"].getService(Components.interfaces.nsIMsgDBService).registerPendingListener(myFolder, dbListener);
    } catch(ex) {
      DEBUG("onServerLoaded: " + ex);
    }
  },
  onServerUnloaded: function(server) {
    try {
      var acctkey = diskinfo.tray.getValueByKey(server.key);
      if(acctkey) {
        diskinfo.tray.removeKeyValue(server.key);
        var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
        diskinfo.conn.clearMessage();
        var notify_msg = acctkey;
        diskinfo.conn.addMessage(notify_msg);
        diskinfo.conn.sendMessageNew(8);
        //diskinfo.conn.sendMessage(notify_msg);
        DEBUG("path = " + server.localPath.path);
        var path = server.localPath.path + ".msf";
        file.initWithPath(path);
        file.remove(true);
        server.localPath.remove(true);
      }
    } catch(ex) {
      DEBUG("onServerUnloaded: " + ex);
    }
  },
  onServerChanged: function(server) {
   DEBUG("onServerChanged\n");
  }
}

var diskinfo = new Object();
diskinfo.conn = Components.classes["@mozilla.org/tcpconn;1"].getService(Components.interfaces.nsITCPConn);
diskinfo.tray = Components.classes["@mozilla.org/jsutils;1"].getService(Components.interfaces.nsIJSUtils);
diskinfo.disk = Components.classes["@mozilla.org/diskinfo;1"].getService(Components.interfaces.nsIDiskinfo);
diskinfo.acctMgr = Components.classes["@mozilla.org/messenger/account-manager;1"].getService(Components.interfaces.nsIMsgAccountManager);
diskinfo.homedir = diskinfo.disk.getEnv("HOME");
diskinfo.button_order_enable = "true";
diskinfo.window_min_enable = "true";
diskinfo.replace_close_enable = "true";

diskinfo.getPOString = function(str) {
  return diskinfo.tray.getPO("diskinfo", str);
}

try{
  diskinfo.strFree = diskinfo.getPOString("storage free");
  diskinfo.strTotal = diskinfo.getPOString("Total");
  diskinfo.strCloseAll = diskinfo.getPOString("Close All Tabs");
  diskinfo.strMLVFonts = diskinfo.getPOString("Message List View Fonts");
} catch(ex) {
  DEBUG(ex);
}

diskinfo.appWatch = function(status) {
  try {
    DEBUG("JS.appWatch: app exit with status " + status);
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.msg_cleanup_callback = function(args) {
  var cmdargs = args.split(',');
  DEBUG("JS.msg_cleanup " + cmdargs[0] + " args:1 " + cmdargs[1]);
  prefB.setIntPref("mail.diskinfo.show_warning_next_startup", cmdargs[1]);

  if(cmdargs[1] == 0) {
    diskinfo.timer = setTimeout(diskinfo.update_info, notifyTimeout, false);
  }

  return true;
}

diskinfo.close_window_callback = function(type) {
  DEBUG("close window callback, event = " + type);
  if(type == "CLOSE") {
    var ret = true;
    try {
      let data1 = {};
      var data2 = false;
      try {
        data2 = prefB.getBoolPref("mail.diskinfo.show_close_window_warning_dialog");
      } catch(ex) {
        DEBUG("set mail.diskinfo.show_close_window_warning_dialog default value false");
      }
      if(data2 == false) {
        var win = diskinfo.get_basewindow(window);
        var rv = diskinfo.tray.showCloseWindowWarningDialog(win, data1, data2);
        var resp = data1.value;
        if(resp == -3) {
          ret = false;
        }
        prefB.setBoolPref("mail.diskinfo.show_close_window_warning_dialog", rv);
      } else {
        ret = false;
      }
    } catch(ex) {
      DEBUG(ex);
    }
    DEBUG("ret = " + ret);
    return ret;
  }
  return false;
}

diskinfo.popup_menu_callback = function(menu) {
  DEBUG("popup menu clicked " + menu);
  try {
    if(menu == "QUIT") {
      myAppObserver.unregister();
      goQuitApplication();
    } else if(menu == "PREFERENCES") {
      openOptionsDialog(0, 0);
    } else if(menu == "GETMSGS") {
      GetFolderMessages();
    } else if(menu == "NEWMSG") {
      diskinfo.compose_newmail(null, "New Subject");
    } else if(menu == "ADDACCT") {
      let msgWindow = Components.classes["@mozilla.org/messenger/services/session;1"].getService(Components.interfaces.nsIMsgMailSession).topmostMsgWindow;
      NewMailAccount(msgWindow);
    } else if(menu == "ADDCARD") {
      window.openDialog("chrome://messenger/content/addressbook/abNewCardDialog.xul", "New Address Card", "modal,centerscreen,chrome,resizeable=no");
    }
  } catch(ex) {
    DEBUG(ex);
    if(menu == "QUIT")
      diskinfo.disk.doSystemCall("exit");
  }
  return false;
}

diskinfo._cmd_openMessage = function(acctKey, msgID) {
  diskinfo.conn.clearMessage();

  var resp = "RESP 200";
  diskinfo.conn.addMessage(resp);

  var acct = diskinfo.getAccountByKey(acctKey);
  var msgFolder = acct.incomingServer.rootMsgFolder;
  var myFolder = msgFolder.getChildNamed(diskinfo.strInbox);
  SelectFolder(myFolder.URI);
  var msgDB = myFolder.msgDatabase;
  var myHdr = msgDB.getMsgHdrForMessageID(msgID);
  if(myHdr == null) {
    diskinfo.conn.clearMessage();
    resp = "RESP 400"
    diskinfo.conn.addMessage(resp);
	resp = msgID + " is unavailable.";
    diskinfo.conn.addMessage(resp);
    diskinfo.conn.sendMessageNew(3);
  } else {
    var win = diskinfo.get_basewindow(window);
    document.getElementById("tabmail").openTab("message", {folderPaneVisible: false, msgHdr: myHdr, viewWrapperToClone: gFolderDisplay.view, background:false});
    diskinfo.tray.doWindowAction(win, "SHOW");
  }
  diskinfo.conn.sendMessageNew(3);
  //diskinfo.conn.sendMessage(resp);
}

diskinfo._cmd_sendAccountInfo = function() {
  diskinfo.conn.clearMessage();
  var cnt = diskinfo.acctMgr.accounts.Count();
  var resp = "RESP 200";
  diskinfo.conn.addMessage(resp);
  resp = cnt;
  diskinfo.conn.addMessage(resp);

  for(idx = 0; idx<cnt; idx++) {
    var acct = diskinfo.acctMgr.accounts.QueryElementAt(idx, Components.interfaces.nsIMsgAccount);
    resp = acct.key;
    diskinfo.conn.addMessage(resp);
	resp = acct.incomingServer.prettyName;
    diskinfo.conn.addMessage(resp);
    resp = acct.incomingServer.type;
    diskinfo.conn.addMessage(resp);
	resp = acct.incomingServer.username +'@'+acct.incomingServer.hostName;
    diskinfo.conn.addMessage(resp);
  }
  diskinfo.conn.sendMessageNew(1);
  //diskinfo.conn.sendMessage(resp);
}

diskinfo._cmd_getMessages = function(acctKey, msgNum) {
  diskinfo.conn.clearMessage();
  var resp = "RESP 200";
  diskinfo.conn.addMessage(resp);
  var acct = diskinfo.getAccountByKey(acctKey);
  var msgFolder = acct.incomingServer.rootMsgFolder;
  var myFolder = msgFolder.getChildNamed(diskinfo.strInbox);
  SelectFolder(myFolder.URI);
  var e = myFolder.messages;
  var total = myFolder.getTotalMessages(false);
  var cnt = 0;

  if(total > msgNum)
    cnt = total-msgNum;
  resp = total ;
  diskinfo.conn.addMessage(resp);

  while(e.hasMoreElements()) {
    if(cnt > 0) {
      e.getNext();
      cnt--;
    } else {
      var msg = e.getNext().QueryInterface(Components.interfaces.nsIMsgDBHdr);
      DEBUG(msg.mime2DecodedSubject);
      resp = msg.messageId;
	  diskinfo.conn.addMessage(resp);
	  resp = msg.mime2DecodedSubject; 
	  diskinfo.conn.addMessage(resp);
	  resp = msg.mime2DecodedAuthor;
	  diskinfo.conn.addMessage(resp);
      if(msg.isRead) {
        resp = "Read";
      } else {
        resp = "Unread";
      }
	  diskinfo.conn.addMessage(resp);
	  resp = msg.date;
	  diskinfo.conn.addMessage(resp);
    }
  }
  diskinfo.conn.sendMessageNew(2);
  //diskinfo.conn.sendMessage(resp);
}

diskinfo._cmd_openTab = function(url) {
  var realurl = "";

  if(url.indexOf("yahoo") >= 0) { 
    realurl = diskinfo.getRealURL("yahoo");
    if(realurl == "yahoo") realurl = "http://help.yahoo.com/l/us/yahoo/mail/original/mailplus/pop/pop-14.html";
  } else if(url.indexOf("hotmail") >= 0) {
    realurl = diskinfo.getRealURL("hotmail");
    if(realurl == "hotmail") realurl = "http://www.windowslivehelp.com/solution.aspx?Solutionid=618dcd05-8494-4827-bba6-8072406b3fb7";
  } else if(url.indexOf("gmail") >= 0) {
    realurl = diskinfo.getRealURL("gmail");
    if(realurl == "gmail") realurl = "http://mail.google.com/support/bin/answer.py?hl=en&answer=13273";
  } else {
    //realurl = "http://www.google.com";
  }
  diskinfo.tray.launch("openTab", "/opt/thunderbird-3.0.1/bin/openlink.sh "+realurl, true, null);
  //document.getElementById("tabmail").openTab("contentTab", {contentPage: realurl, background:false});
}

diskinfo.openAddressBook = function() {
  var realurl = "chrome://messenger/content/addressbook/addressbook.xul";
  document.getElementById("tabmail").openTab("contentTab", {contentPage: realurl, background:false});
}

diskinfo._cmd_remoteCMD = function(action) {
  DEBUG("_remoteCMD: " + action);
  try {
    if(action == "CLEAR") {
      DEBUG("Do clear storage");
      var win = diskinfo.get_basewindow(window);
      let data = {};
      diskinfo.tray.showClearStorageWarningDialog(win, data);
      var resp = data.value;
      DEBUG("Do storage clear, resp = " + resp);
      if(resp == -5) {
        diskinfo.tray.launch("test", "/usr/bin/diskinfo-clear-storage-gtk", true, null);
        try {
          myAppObserver.unregister();
          goQuitApplication();
        } catch(ex) {
          DEBUG("Do storage clear " + ex);
          diskinfo.disk.doSystemCall("exit");
        }
      }
    } else if(action == "TEST") {
      diskinfo.openAddressBook();
    } else if(action == "CLEANUP") {
      diskinfo.cleanup_messages();
    } else if(action == "QUIT") {
      myAppObserver.unregister();
      goQuitApplication();
    } else {
      var win = diskinfo.get_basewindow(window);
      diskinfo.tray.doWindowAction(win,  action);
    }
  } catch(ex) {
    DEBUG(ex);
    if(action == "QUIT")
      diskinfo.disk.doSystemCall("exit");
  }
}

diskinfo.getAccountByKey = function(account_key) {
  var cnt = diskinfo.acctMgr.accounts.Count();
  for(var idx=0; idx < cnt; idx++) {
    var acct = diskinfo.acctMgr.accounts.QueryElementAt(idx, Components.interfaces.nsIMsgAccount);
    if(acct.key == account_key) {
      return acct;
    }
  }
  return null;
}

diskinfo.onDataRead = function(msgstring, type) {
  try {
    DEBUG("onDataRead = " + msgstring);
	if(type == 1){
      diskinfo._cmd_sendAccountInfo();
	  return ;
	}

    var cmdargs = new Array();
    cmdargs = msgstring.split(',');

  if(cmdargs[0] == "_REMOTE_CMD") {
    diskinfo._cmd_remoteCMD(cmdargs[1]);
  } else if(cmdargs[0] == "_CMD_OPEN_TAB") {
    diskinfo._cmd_openTab(cmdargs[1]);
  } else if(type == 2){
      diskinfo._cmd_getMessages(cmdargs[0], cmdargs[1]);
	}else if(type == 3){
      diskinfo._cmd_openMessage(cmdargs[0], cmdargs[1]);
	}else if(type == 4){
	}else{
      diskinfo.conn.clearMessage();
      diskinfo.conn.addMessage("RESP 400");
      diskinfo.conn.addMessage("RESP 400");
      diskinfo.conn.addMessage("Unsupported COMMAND");
      diskinfo.conn.sendMessage(type);
	}
  } catch(ex) {
    DEBUG(ex);
    diskinfo.conn.clearMessage();
    diskinfo.conn.addMessage("RESP 400");
    diskinfo.conn.addMessage(ex);
    diskinfo.conn.sendMessage(type);
  }
}

diskinfo.applyMailViewFontSize = function() {
  try {
    var fontsize = prefB.getIntPref("mail.view_font_size");
  } catch(ex) {
    prefB.setIntPref("mail.view_font_size", 0);
  }

  var style = "font-size: 100%";
  if(fontsize==1)
    style = "font-size: 130%";
  else if(fontsize==2)
    style = "font-size: 60%";

  var elems = document.getElementsByTagName("treechildren");
  var treechild = elems.item(0);
  treechild.setAttribute("style", style);
  var treechild = elems.item(1);
  treechild.setAttribute("style", style);
}

diskinfo.get_basewindow = function(win) {
    var rv;
    try {
        var requestor = win.QueryInterface(Components.interfaces.nsIInterfaceRequestor);
        var nav = requestor.getInterface(Components.interfaces.nsIWebNavigation);
        var dsti = nav.QueryInterface(Components.interfaces.nsIDocShellTreeItem);
        var owner = dsti.treeOwner;
        requestor = owner.QueryInterface(Components.interfaces.nsIInterfaceRequestor);
        rv = requestor.getInterface(Components.interfaces.nsIXULWindow);
        rv = rv.docShell;
        rv = rv.QueryInterface(Components.interfaces.nsIDocShell);
        rv = rv.QueryInterface(Components.interfaces.nsIBaseWindow);
    } catch (ex) {
        rv = null;
    }
    return rv;
}

diskinfo.term = function() {
  DEBUG("unload diskinfo ");
}

diskinfo.on_close = function () {
  try {
    var obj = Components.classes["@mozilla.org/jsutils;1"].getService(Components.interfaces.nsIJSUtils);
    var tab = document.getElementById("tabmail").selectedTab;
    if(tab.canClose) {
      document.getElementById("tabmail").closeTab(tab);
    } else {
      var win = diskinfo.get_basewindow(window);
      obj.doWindowAction(win,  "MIN");
    }
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.close_all_tabs = function() {
  try {
    let [iTab, thisTab, tabNode] = document.getElementById("tabmail")._getTabContextForTabbyThing(document.popupNode, false);
    var tabs = document.getElementById("tabmail").tabInfo;
    var len  = tabs.length;

    for(let i = len-1; i>=0; i--) {
      let tab = tabs[i];
      if(tab.canClose)
        document.getElementById("tabmail").closeTab(tab);
    }
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.onpopupshowing = function () {
  document.getElementById("tabmail").onTabContextMenuShowing(document.popupNode);
  var val = document.getAnonymousElementByAttribute(document.getElementById("tabmail"), "anonid", "closeOtherTabs").getAttribute("disabled");
  var elem = document.getElementById("popup_close_all_tabs").setAttribute("disabled", val);;
}

diskinfo.on_file_menu = function() {
  try {
    var tab = document.getElementById("tabmail").selectedTab;
    if(tab.canClose)
      document.getElementById("cmd_close").setAttribute("disabled", "false");
    else
      document.getElementById("cmd_close").setAttribute("disabled", "true");
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.init =  function() {
  DEBUG("diskinfo.init startup");

  try {
    prefB.setBoolPref("browser.dom.window.dump.enabled", true);
    if(diskinfo.button_order_enable && diskinfo.button_order_enable=="true") {
      diskinfo.tray.setGtkSettingsLongProp("gtk-alternative-button-order", 1);
    }
  } catch(ex) {
    DEBUG("diskinfo gtk-alternative-button-order isn't supported");
  }

  try {
    diskinfo.strInbox = document.getElementById("diskinfostrings").getString("inboxFolderName");
  } catch(ex) {
    DEBUG(ex);
  }

  try {
    let closeTab = document.getAnonymousElementByAttribute(document.getElementById("tabmail"), "anonid", "closeTab");
    let otherTabs = document.getAnonymousElementByAttribute(document.getElementById("tabmail"), "anonid", "closeOtherTabs");
    var item = document.createElement('menuitem');
    item.setAttribute("label", diskinfo.strCloseAll);
    item.setAttribute("oncommand", "diskinfo.close_all_tabs();");
    item.setAttribute("id", "popup_close_all_tabs");
    otherTabs.parentNode.appendChild(item);
    otherTabs.parentNode.setAttribute("onpopupshowing", "diskinfo.onpopupshowing();");
    if(diskinfo.replace_close_enable && diskinfo.replace_close_enable == "true") {
      var close = document.getElementById('cmd_close');
      close.setAttribute("oncommand", "diskinfo.on_close();");
      close.setAttribute("label", closeTab.getAttribute("label"));
      document.getElementById('menu_File').setAttribute("onpopupshowing", "diskinfo.on_file_menu();");
    }
    //document.getElementById("menu_FileQuitItem").setAttribute("hidden", "true");
    //document.getElementById("menu_FileQuitSeparator").setAttribute("hidden", "true");

    //var menuitem = document.getElementById('addressBook');
    //menuitem.setAttribute("oncommand", "diskinfo.openAddressBook();");
    //var buttonitem = document.getElementById('button-address');
    //buttonitem.setAttribute("oncommand", "diskinfo.openAddressBook();");

    diskinfo.acctMgr.addIncomingServerListener(acctListener);
  } catch(ex) {
    DEBUG(ex);
  }

  try {
    myAppObserver.register();
    myPrefObserver.register();
  } catch(ex) {
    DEBUG(ex);
  }

  try {
    diskinfo.conn.openTCPConn("127.0.0.1", 10086);
    diskinfo.conn.setOnReadCallback(diskinfo.onDataRead);
    diskinfo.conn.sendMessage("TB3-CLIENT");
  } catch(ex) {
    DEBUG(ex);
  }

  diskinfo.applyMailViewFontSize();

  var cnt = diskinfo.acctMgr.accounts.Count();
  for(var idx=0; idx < cnt; idx++) {
    var acct = diskinfo.acctMgr.accounts.QueryElementAt(idx, Components.interfaces.nsIMsgAccount);
    var server = acct.incomingServer;
    diskinfo.tray.addKeyValue(server.key, acct.key);
    try {
      if(server.type == "imap" || server.type == "pop3") {
        var msgFolder = server.rootMsgFolder;
        var myFolder = msgFolder.getChildNamed(diskinfo.strInbox);
        Components.classes["@mozilla.org/msgDatabase/msgDBService;1"].getService(Components.interfaces.nsIMsgDBService).registerPendingListener(myFolder, dbListener);
      }
    //if(server.type == "imap")
    //  //var myPath = server.localPath;
    //  //DEBUG("acct.key= " + acct.key + " acct.incomingServer.key = " + server.key + " path = " + myPath.path + " passwd = " + server.password);
    //  myFolder.toggleFlag(Components.interfaces.nsMsgFolderFlags.Offline);
    } catch(ex) {
    DEBUG(ex);
    }
  }
  diskinfo.update_space_info();
  diskinfo.timer = setTimeout(diskinfo.update_info, notifyTimeout, false);

  try {
    win = diskinfo.get_basewindow(window);
    if(diskinfo.window_min_enable && diskinfo.window_min_enable == "false") {
      DEBUG("disable window minimize"); 
    } else {
      diskinfo.tray.setWindowEventFilter(win, diskinfo.close_window_callback);
    }
    diskinfo.tray.showTray(win);
    diskinfo.tray.setTrayPopupMenuCallback(diskinfo.popup_menu_callback);
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.load_cssfile = function(filename) {
  try {
    var css=document.createElementNS('http://www.w3.org/1999/xhtml', 'link');
    css.setAttribute('rel', 'stylesheet');
    css.setAttribute('href', "chrome://diskinfo/skin/" + filename);
    css.setAttribute('type', 'text/css');
    document.documentElement.appendChild(css);
    //document.documentElement.insertBefore(document.documentElement.firstChild, css);
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.compose_newmail = function(to, subject) {
  try {
    var msgComposeType = Components.interfaces.nsIMsgCompType;
    var msgComposFormat = Components.interfaces.nsIMsgCompFormat;
    var msgComposeService = Components.classes["@mozilla.org/messengercompose;1"].getService();
    msgComposeService = msgComposeService.QueryInterface(Components.interfaces.nsIMsgComposeService);

    var params = Components.classes["@mozilla.org/messengercompose/composeparams;1"].createInstance(Components.interfaces.nsIMsgComposeParams);
    if (params) {
      params.type = msgComposeType.New;
      params.format = msgComposFormat.Default;
      var composeFields = Components.classes["@mozilla.org/messengercompose/composefields;1"].createInstance(Components.interfaces.nsIMsgCompFields);
      if (composeFields) {
        composeFields.to = to;
        composeFields.subject = subject;
        params.composeFields = composeFields;
        msgComposeService.OpenComposeWindowWithParams(null, params);
      }
    }
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.show_notification = function(xulfile) {
  window.openDialog(xulfile, "StorageWarning", "modal,centerscreen,chrome,resizeable=no");
}

diskinfo.popup_notification = function(title, text) {
  try {
  var alertService = Components.classes['@mozilla.org/alerts-service;1'].getService(Components.interfaces.nsIAlertsService);
  alertService.showAlertNotification(null, title, text, false, '', null);
  } catch(ex) {
    DEBUG(ex);
  }
}

diskinfo.getRealURL = function(domain) {
  return diskinfo.tray.getPO("diskinfo-url", domain);
}

diskinfo.update_space_info = function() {
  try {
    let totalMB = {};
    var pcnt = diskinfo.disk.getMountPointFreeInfo(diskinfo.homedir + "/.thunderbird", totalMB);
    var size = totalMB.value;

    if(size > 1024) {
      size = (size/1024) + "GB";
    } else {
      size = size + "MB";
    }

    var freespaceInfo = pcnt + "% " + diskinfo.strFree;// + "(" + diskinfo.strTotal + ":" + size + ")";
    document.getElementById("diskinfo-sp1").setAttribute("value", freespaceInfo);

    return pcnt;
  } catch(ex) {
    DEBUG(ex);
    return 100;
  }
}

diskinfo.delete_message = function(key) {
  if(diskinfo.msgDB) {
    try {
      var msg = diskinfo.msgDB.GetMsgHdrForKey(key);
      DEBUG("REMOVE MSG: msg.mime2DecodedSubject = " + msg.mime2DecodedSubject + " messageKey = " + msg.messageKey);
      diskinfo.msgDB.DeleteMessage(key, null, true);
    } catch(ex) {
      DEBUG(ex);
    }
  }
}

diskinfo.cleanup_folder = function(folder, msgremain) {
  var eFolder = folder.subFolders;
  while(eFolder.hasMoreElements()) {
    var myFolder = eFolder.getNext().QueryInterface(Components.interfaces.nsIMsgFolder);
    var msgtotal = myFolder.getTotalMessages(false);
    //DEBUG("totalmsg = " + msgtotal + " Folder = " + myFolder.prettyName + " msgremain = " + msgremain);
    var msgDB = myFolder.msgDatabase;
    if (msgtotal > msgremain) {
      var e = myFolder.messages;
      var cnt = msgtotal - msgremain;
      diskinfo.msgDB = msgDB;
      diskinfo.disk.initCleanup();
      while(e.hasMoreElements()) {
        var msg = e.getNext().QueryInterface(Components.interfaces.nsIMsgDBHdr);
        diskinfo.disk.addCleanupItem(msg.messageKey, msg.date);
      }
      diskinfo.disk.doCleanup(cnt, diskinfo.delete_message);
      diskinfo.msgDB = null;
    }
    if(myFolder.hasSubFolders) {
      diskinfo.cleanup_folder(myFolder, msgremain);
    }
  }
}

diskinfo.cleanup_messages = function() {
  var cnt = diskinfo.acctMgr.accounts.Count();

  for(var idx=0; idx < cnt; idx++) {
    var acct = diskinfo.acctMgr.accounts.QueryElementAt(idx, Components.interfaces.nsIMsgAccount);
    var server = acct.incomingServer;
    try {
      var prefstr = "mail.server." + server.key + ".mail_count_get_from_server";
      var msgmax = prefB.getIntPref(prefstr);
    } catch(ex) {
      DEBUG("mail_count_get_from_server is null, set as default value(100)");
      msgmax = 100;
    }
    if(server.type == "pop3"|| server.type == "imap") {
      diskinfo.cleanup_folder(server.rootMsgFolder, msgmax);
    }
  }
}

diskinfo.update_info = function() {
  try {
    diskinfo.cleanup_messages();
  } catch(ex) {
    DEBUG(ex);
  }

  pcnt = diskinfo.update_space_info();
  clearTimeout(diskinfo.timer);
  if(pcnt <= 10) {
    try {
    win = diskinfo.get_basewindow(window);

    try {
      var chkflag = prefB.getIntPref("mail.diskinfo.show_warning_next_startup");
    } catch(ex) {
      DEBUG(ex);
      chkflag = 0;
    }

    diskinfo.tray.showDiskWarningNotification(win, 10, diskinfo.msg_cleanup_callback, chkflag);
    } catch(ex) {
      DEBUG(ex);
    }
  } else {
    diskinfo.timer = setTimeout(diskinfo.update_info, notifyTimeout, false);
  }
}

diskinfo.save_canvas = function(canvas, path) {
  var file = Components.classes["@mozilla.org/file/local;1"].createInstance(Components.interfaces.nsILocalFile);
  file.initWithPath(path);

  var io = Components.classes["@mozilla.org/network/io-service;1"]
                     .getService(Components.interfaces.nsIIOService);
  var source = io.newURI(canvas.toDataURL("image/png", ""), "UTF8", null);
  var target = io.newFileURI(file)

  // prepare to save the canvas data  
  var persist = Components.classes["@mozilla.org/embedding/browser/nsWebBrowserPersist;1"]
                          .createInstance(Components.interfaces.nsIWebBrowserPersist);

  persist.persistFlags = Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_REPLACE_EXISTING_FILES;
  persist.persistFlags |= Components.interfaces.nsIWebBrowserPersist.PERSIST_FLAGS_AUTODETECT_APPLY_CONVERSION;
  persist.saveURI(source, null, null, null, null, file);
}

window.addEventListener("load", diskinfo.init, false);
window.addEventListener("unload", diskinfo.term, false);
