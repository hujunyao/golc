#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include "uartctrl.h"

#define DEBUG_PRINT(level, fmt) printf fmt
#define COUNT_OF(arr)           (sizeof(arr) / sizeof(arr[0]))

#define DEFAULT_READ_TIMEOUT    1

CUartCtrl::CUartCtrl(const char *device)
    : m_device(device)
    , m_fd(-1)
    , m_isOpened(false)
{
}

CUartCtrl::~CUartCtrl()
{
    close();
}

bool CUartCtrl::open()
{
    if (m_isOpened)
    {
        printf("CUartCtrl::Open - Device is already opened!\n");
        return true;
    }

    int fd = ::open(m_device, O_NONBLOCK | O_RDWR);
    if (fd < 0)
    {
        printf("CUartCtrl::Open - Open device [%s] failed!\n", m_device);
        return false;
    }

    m_fd = fd;
    m_isOpened = true;

    return true;
}

bool CUartCtrl::close()
{
    if (!m_isOpened)
    {
        printf("CUartCtrl::Close - Device is already closed!\n");
        return true;
    }

    ::close(m_fd);
    m_fd = -1;
    m_isOpened = false;

    return true;
}

bool CUartCtrl::setSpeed(int speed) const
{
    if ( !m_isOpened )
    {
        printf("CUartCtrl::SetSpeed - Device is not opened!\n");
        return false;
    }

    const int speed_arr[] = { B921600, B460800, B115200, B38400, B19200, B9600, B4800, B2400, B1200, B300, };
    const int name_arr[]  = {  921600,  460800,  115200,  38400,  19200,  9600,  4800,  2400,  1200,  300, };

    unsigned int i;
    int ret = 0;
    struct termios options;

    for (i = 0; i < COUNT_OF(speed_arr); ++ i)
    {
        if (speed == name_arr[i])
        {
            ret = tcgetattr(m_fd, &options);
            if (ret != 0)
            {
                return false;
            }
            tcflush(m_fd, TCIOFLUSH);
            cfsetispeed(&options, speed_arr[i]);
            cfsetospeed(&options, speed_arr[i]);
            ret = tcsetattr(m_fd, TCSANOW, &options);
            return ((ret == 0) ? true : false);
        }
    }

    return false;
}

bool CUartCtrl::setParity(int databits, int parity, int stopbits) const
{
    if ( !m_isOpened )
    {
        printf("CUartCtrl::SetParity - Device is not opened!\n");
        return false;
    }

    int ret = 0;
    struct termios options;

    ret = tcgetattr(m_fd, &options);
    if (ret != 0)
    {
        return false;
    }

    options.c_cflag &= ~CSIZE;

    switch (databits)
    {
    case 7:
        options.c_cflag |= CS7;
        break;
    case 8:
        options.c_cflag |= CS8;
        break;
    default:
        return false;
    }

    switch (parity)
    {
    case 'n':
    case 'N':
        options.c_cflag &= ~PARENB; /* Clear parity enable */
        options.c_iflag &= ~INPCK;  /* Enable parity checking */
        break;
    case 'o':
    case 'O':
        options.c_cflag |= (PARODD | PARENB);
        options.c_iflag |= INPCK;   /* Disnable parity checking */
        break;
    case 'e':
    case 'E':
        options.c_cflag |= PARENB;  /* Enable parity */
        options.c_cflag &= ~PARODD;
        options.c_iflag |= INPCK;   /* Disnable parity checking */
        break;
    case 'S':
    case 's':
        /*as no parity*/
        options.c_cflag &= ~PARENB;
        options.c_cflag &= ~CSTOPB;
        options.c_iflag |= INPCK;   /* Disnable parity checking */
        break;
    default:
        return false;
    }

    switch (stopbits)
    {
    case 1:
        options.c_cflag &= ~CSTOPB;
        break;
    case 2:
        options.c_cflag |= CSTOPB;
        break;
    default:
        return false;
    }

    /* Set raw mode. */
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG); /*Input*/
    options.c_oflag &= ~OPOST;                          /*Output*/

    /* Don't treat <CR> as <LF>.*/
    options.c_iflag &= ~(INLCR | ICRNL | IGNCR);
    options.c_oflag &= ~(ONLCR | OCRNL);

    tcflush(m_fd, TCIFLUSH);
    options.c_cc[VTIME] = 150; /* Set timeout 15 seconds*/
    options.c_cc[VMIN] = 0;    /* Update the options and do it NOW */

    ret = tcsetattr(m_fd, TCSANOW, &options);
    return ((ret == 0) ? true : false);
}

int CUartCtrl::write(char *buffer, int bufferLength) const
{
    if (!m_isOpened)
    {
        printf("CUartCtrl::Write - Device is not opened!\n");
        return -1;
    }

    if (NULL == buffer || bufferLength <= 0)
    {
        printf("CUartCtrl::Write - Wrong data buffer to write!\n");
        return -1;
    }

    return ::write(m_fd, buffer, bufferLength);
}

int CUartCtrl::read(char *buffer, int bufferLength) const
{
    if (!m_isOpened)
    {
        printf("CUartCtrl::Read - Device is not opened!\n");
        return -1;
    }

    if (NULL == buffer || bufferLength <= 0)
    {
        printf("CUartCtrl::Read - Wrong data buffer to read!\n");
        return -1;
    }

    return ::read(m_fd, buffer, bufferLength);
}

int CUartCtrl::getFileDescriptor() const
{
    return m_fd;
}
