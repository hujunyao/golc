#ifndef __UARTCTRL_H__
#define __UARTCTRL_H__

class CUartCtrl
{
public:
    CUartCtrl(const char *device);
    ~CUartCtrl();

    bool open();
    bool close();

    bool setSpeed(int speed) const;

    bool setParity(int databits, int parity, int stopbits) const;

    int write(char *buffer, int bufferLength) const;
    int read(char *buffer, int bufferLength) const;

    int getFileDescriptor() const;

private:
    const char *m_device;
    int m_fd;
    bool m_isOpened;
};

#endif // __UARTCTRL_H__
